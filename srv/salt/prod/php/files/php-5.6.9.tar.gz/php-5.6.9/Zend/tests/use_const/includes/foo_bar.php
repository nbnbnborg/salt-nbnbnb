<?php

namespace foo;

const bar = 'local bar';
